import {
  FaDev,
  FaInfoCircle,
  GoTools,
  IoIosDocument,
  IoIosPaperPlane,
  MdPerson,
} from "../components/Icons";

const sections = [
  { id: "about-me", title: "Sobre Mi", icon: MdPerson },
  /*
  { id: "work", title: "Work", icon: MdWork },
  { id: "education", title: "Education", icon: MdSchool },
  */
  { id: "skills", title: "Habilidades", icon: GoTools },
  { id: "projects", title: "Trabajos", icon: FaDev },
  /*
  { id: "blog", title: "Blog", icon: IoIosJournal },
  { id: "languages", title: "Languages", icon: FaSignLanguage },
  { id: "achievements", title: "Achievements", icon: FaAward },
  {
    id: "certifications",
    title: "Certifications",
    icon: AiFillSafetyCertificate,
  },
  { id: "philanthropy", title: "Philanthropy", icon: FaBoxOpen },
  { id: "photography", title: "Photography", icon: AiFillInstagram },
  { id: "music", title: "Music", icon: MdMusicNote },
  { id: "design", title: "Design", icon: FaPaintBrush },
  */
  { id: "resume", title: "Resume", icon: IoIosDocument },
  /* { id: "contact", title: "Contacto", icon: IoIosPaperPlane }, */
  { id: "footer", title: "About RotW", icon: FaInfoCircle },
];

export default sections;

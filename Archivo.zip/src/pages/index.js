import React from "react";
import styles from "./index.module.css";

import { Wrapper } from "../components";

import {
  Footer,
  AboutMe,
  Blog,
  Hero,
  Projects,
  Skills,
} from "../sections";

const IndexPage = () => {
  return (
    <Wrapper>
      <div className={`container ${styles.layout}`}>
        <Hero />
        <AboutMe />
        <div className={styles.workEducation}>
          {/* <Work /> */}
          {/* <Education /> */}
        </div>
        <Skills />
        <Projects />
        <Blog />
        {/*
        <Languages />
        <div className={styles.achievementsCertificationPhilanthropy}>
          <div>
            <Achievements />
          </div>
          <div>
            <Certifications />
          </div>
          <div>
            <Philanthropy />
          </div>
        </div>
        <Photography />
        <Music />
        <Design />
        <Resume />
        <Contact />
        */}
        <Footer />
      </div>
    </Wrapper>
  );
};

export default IndexPage;

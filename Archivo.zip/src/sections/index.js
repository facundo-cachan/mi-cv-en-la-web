import Footer from "./Footer";
import AboutMe from "./AboutMe";
import Blog from "./Blog";
import Contact from "./Contact";
import Hero from "./Hero";
import Languages from "./Languages";
import Projects from "./Projects";
import Resume from "./Resume";
import Skills from "./Skills";
import Work from "./Work";
export {
  Footer,
  AboutMe,
  Blog,
  Contact,
  Hero,
  Languages,
  Projects,
  Resume,
  Skills,
  Work,
};

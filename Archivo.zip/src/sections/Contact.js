import React, { useRef, useState } from "react";

import { Button, Heading, Icons } from "../components";

const Contact = () => {
  const { IoIosPaperPlane } = Icons,
    nameRef = useRef(null),
    [name, setName] = useState(""),
    emailRef = useRef(null),
    [email, setEmail] = useState(""),
    messageRef = useRef(null),
    [message, setMessage] = useState(""),
    [buttonText, setButtonText] = useState("Enviar"),
    isEmailValid = email => {
      var re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      return re.test(String(email).toLowerCase());
    },
    onSubmit = e => {
      let formValid = true;
      e.preventDefault();

      if (!name) {
        formValid = false;
        const nodeName = nameRef.current;
        nodeName.classList.add("border-red-500", "animated", "shake");
        setTimeout(() => {
          nodeName.classList.remove("border-red-500", "animated", "shake");
        }, 2000);
      }

      if (!email || !isEmailValid(email)) {
        formValid = false;
        const nodeName = emailRef.current;
        nodeName.classList.add("border-red-500", "animated", "shake");
        setTimeout(() => {
          nodeName.classList.remove("border-red-500", "animated", "shake");
        }, 2000);
      }

      if (!message) {
        formValid = false;
        const nodeName = messageRef.current;
        nodeName.classList.add("border-red-500", "animated", "shake");
        setTimeout(() => {
          nodeName.classList.remove("border-red-500", "animated", "shake");
        }, 2000);
      }

      if (formValid) {
        const url = "api/sendEmail";
        const opts = {
          method: "POST",
          body: JSON.stringify({ name, email, message }),
        };

        fetch(url, opts)
          .then(() => {
            setButtonText("Mensaje Enviado!");
            setName("");
            setEmail("");
            setMessage("");
          })
          .catch(() => setButtonText("Ha ocurrido un error!"));
      }
    };

  return (
    <section id="contact">
      <Heading icon={IoIosPaperPlane} title="Contacto" />
      <form className="lg:w-2/3 xl:w-1/2">
        <label htmlFor="name" className="w-4/5 md:w-2/3 flex flex-col">
          <h6 className="font-semibold text-sm mb-2">Nombre</h6>
          <input
            required
            id="name"
            name="name"
            type="text"
            ref={nameRef}
            placeholder="Jhon Smith"
            value={name}
            onChange={e => setName(e.target.value)}
            className="border-2 border-gray-700 focus:border-gray-300 px-4 py-2 text-lg bg-transparent duration-200 focus:outline-none"
          />
          <p className="text-xs mt-2">Como puedo llamarte?</p>
        </label>

        <label htmlFor="email" className="mt-2 w-4/5 md:w-2/3 flex flex-col">
          <h6 className="font-semibold text-sm mb-2">Email</h6>
          <input
            required
            id="email"
            name="email"
            type="email"
            ref={emailRef}
            value={email}
            placeholder="jhon@smith.com"
            onChange={e => setEmail(e.target.value)}
            className="border-2 border-gray-700 focus:border-gray-300 px-4 py-2 text-lg bg-transparent duration-200 focus:outline-none"
          />
          <p className="text-xs mt-2">
            Podes enviarme email, o contactarme por las redes ...
          </p>
        </label>

        <label htmlFor="message" className="mt-2 flex flex-col">
          <h6 className="font-semibold text-sm mb-2">Mensaje</h6>
          <textarea
            required
            rows="4"
            id="message"
            name="message"
            ref={messageRef}
            value={message}
            placeholder="Escribe tu mensaje ..."
            onChange={e => setMessage(e.target.value)}
            className="border-2 border-gray-700 focus:border-gray-300 px-4 py-2 text-lg bg-transparent duration-200 focus:outline-none"
          />
          <p className="text-xs mt-2">
            Contame en que proyecto podemos trabajar ...
          </p>
        </label>

        <Button
          type="submit"
          className="mt-6"
          icon={IoIosPaperPlane}
          title={buttonText}
          onClick={onSubmit}
        />
      </form>
    </section>
  );
};

export default Contact;

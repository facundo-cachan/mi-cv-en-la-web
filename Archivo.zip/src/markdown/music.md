---
id: "music"
---

If you've read about my profile so far and you found it interesting, studies show that knowing what type of music a person listens to would say a lot about them.

Also, I've been known for my good taste in music and I've always wanted to share the latest and greatest hits through an easy medium, so here's a Spotify Playlist I've created called **My Everyday: A dynamic playlist of what's on my daily roster of music.**

---
id: "about-me"
---

Hola!

Soy Facundo Cachan, como ya habras le&iacute;do, soy dise&ntilde;ador y desarrollador web, y de aplicaciones, tanto para la web, como para m&oacute;viles, o sea, para tu tel&eacute;fono.

Este sitio es producto de algunas de las cosas que aprend&iacute; sobre el mundo de la programaci&oacute;n y las nuevas t&eacute;cnologias, y m&aacute;s importante gracias al aporte de un colega.

Me met&iacute; en el desarrollo porque las computadoras siempre me han fascinado, solo ver que desde un documento de texto en blanco, con algo de c&oacute;digo se convierte en cosas que usamos regularmente, como Instagram o Mercado Libre fue nada menos que m&aacute;gico para m&iacute; y ah&iacute; es donde comenz&oacute; mi b&uacute;squeda para inventar.

Cre&eacute; este sitio web para poder mostrar todo esto y, a trav&eacute;s de este proceso, facilitar la conexi&oacute;n conmigo. Si te gusta lo que ves, desde el formulario de [contacto](#contact) pod&eacute;s env&iacute;arme un mensaje y nos ponemos en contacto  💌
